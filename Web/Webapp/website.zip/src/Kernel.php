<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace App;

use Symfony\Bundle\FrameworkBundle\Kernel\MicroKernelTrait;
use Symfony\Component\HttpKernel\Kernel as BaseKernel;
use CTFSecurity\Flag;

class Kernel extends BaseKernel
{
    use MicroKernelTrait;

    public function __construct(string $environment = 'dev', bool $debug = false)
    {
        if (Flag::checkLicense($_ENV['LICENSE_KEY'])){
            parent::__construct($environment, $debug);
        }
    }
}
